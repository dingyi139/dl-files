package protocol // import "github.com/xtls/xray-core/common/protocol"
