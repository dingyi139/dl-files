// Package buf provides a light-weight memory allocation mechanism.
package buf

//go:generate go run github.com/v2fly/v2ray-core/v5/common/errors/errorgen
